from datetime import datetime, timedelta, timezone
import pandas as pd
from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS


class InfluxDbControl:
    def __init__(self, host: str, port: int, org: str, token: str):
        _url = f'http://{host}:{port}'
        self._client = InfluxDBClient(url=_url, org=org, token=token)
        self._buckets_api = self._client.buckets_api()
        self._write_api = self._client.write_api(write_options=SYNCHRONOUS)
        self._query_api = self._client.query_api()
        self._delete_api = self._client.delete_api()

    def close(self):
        self._client.close()

    def get_bucket_list(self):
        buckets = self._buckets_api.find_buckets().buckets
        bucket_name_list = []
        for bucket in buckets:
            bucket_name_list.append(bucket.name)
        return bucket_name_list

    def insert_data(self, bucket: str, measurement: str, 
                    data_list: list[list[float]], datetime_list: list[datetime],
                    column_list: list[str], tag_data: dict = {}):
        df = pd.DataFrame(data=data_list, columns=column_list,)
        df['timestamp'] = [dt.timestamp() * 1000 for dt in datetime_list]
        df.set_index('timestamp', inplace=True)
        df.index = pd.to_datetime(df.index, unit='ms')

        tag_column_list = []
        for tag_key, tag_value in tag_data.items():
            df[tag_key] = tag_value
            tag_column_list.append(tag_key)

        with self._write_api as writer:
            writer.write(bucket=bucket, record=df, data_frame_measurement_name=measurement, data_frame_tag_columns=tag_column_list)

    def read_data(self, bucket: str, measurement: str,
                  start_datetime: datetime, end_datetime: datetime, tag_data: dict = {}):
        start = int(start_datetime.astimezone(timezone.utc).timestamp())
        stop = int(end_datetime.astimezone(timezone.utc).timestamp())
        query = f'from(bucket: "{bucket}") ' \
                f'|> range(start: {start}, stop: {stop}) ' \
                f'|> filter(fn: (r) => r._measurement == "{measurement}") '
        for tag_key, tag_value in tag_data.items():
            query += f'|> filter(fn: (r) => r.{tag_key} == "{tag_value}") '
        query += f'|> aggregateWindow(every: 1s, fn: mean, createEmpty: false)'
        df = self._query_api.query_data_frame(query=query)
        return df
    
    # def read_data(self, bucket: str, measurement: str, start_datetime: datetime, end_datetime: datetime):
    #     start = start_datetime.isoformat('T', 'seconds') + 'Z'
    #     stop = end_datetime.isoformat('T', 'seconds') + 'Z'
    #     query = f'from(bucket: "{bucket}") ' \
    #             f'|> range(start: {start}, stop: {stop}) ' \
    #             f'|> filter(fn: (r) => r._measurement == "{measurement}") ' \
    #             f'|> aggregateWindow(every: 1s, fn: mean, createEmpty: false)'
    #
    #     df = self._query_api.query_data_frame(query=query)
    #     return df

    def delete_data(self, bucket: str, measurement: str, 
                    start_datetime: datetime, end_datetime: datetime, 
                    tag_data: dict = {}):
        predicate = f'_measurement={measurement}'
        for tag_key, tag_value in tag_data.items():
            predicate += f' AND {tag_key}={tag_value}'

        self._delete_api.delete(start=start_datetime, stop=end_datetime, predicate=predicate, bucket=bucket)


if __name__ == '__main__':
    _influxdb_control = InfluxDbControl(host='192.168.0.104', port=8086, org='data_lake',
                                        token='X3XvO-YE9t6Y3Cq-_rfmLM9frm3g8MLDk-JqpZATlaIhdiPmtHpjmkwWknGG0c-Goewsiv9Mkh7MPaPT0Jp9Ew==')

    _bucket_name_list = _influxdb_control.get_bucket_list()

    print(_bucket_name_list)

    bucket = 'test_data'
    measurement = 'test_1'
    column_list = ['value_1']
    tag_data = {
        'dataset_id': 'test_data_set_',
        'remark': 'insert_test'
    }

    now = datetime.now()
    _data_list = [[float(i + 1)] for i in range(1000)]
    _datetime_list = [now - timedelta(seconds=1000 - i) for i in range(1000)]
    # _influxdb_control.insert_data(bucket=bucket, measurement=measurement, 
    #                               data_list=_data_list, datetime_list=_datetime_list,
    #                               column_list= column_list, tag_data=tag_data)

    _start_datetime = _datetime_list[0]
    _end_datetime = _datetime_list[-1]
    _df = _influxdb_control.read_data(bucket=bucket, measurement=measurement, 
                                      start_datetime=_start_datetime, end_datetime=_end_datetime)
    
    # _delete_start_datetime = datetime(year=2024, month=1, day=1)
    # _delete_end_datetime = datetime(year=2025, month=1, day=1)
    # _influxdb_control.delete_data(bucket=bucket, measurement=measurement,
    #                               start_datetime=_delete_start_datetime, end_datetime=_delete_end_datetime,
    #                               tag_data=tag_data)


    _influxdb_control.close()

    print('end')
