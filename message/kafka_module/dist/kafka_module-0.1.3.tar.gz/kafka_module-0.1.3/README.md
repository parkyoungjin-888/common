 
## Version
### 0.1.1 : consumer, rawdata model 추가

### 0.1.2 : consumer callback 함수를 쓰도록 변경

### 0.1.3 : 이미지 전송 기능 추가
