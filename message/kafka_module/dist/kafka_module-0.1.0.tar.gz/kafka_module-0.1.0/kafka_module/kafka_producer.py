from kafka import KafkaProducer
from json import dumps


class KafkaProducerControl:
    def __init__(self, host: str, port: int, topic: str):
        self.topic = topic
        self.producer = KafkaProducer(acks=0,
                                      compression_type='gzip',
                                      bootstrap_servers=[f'{host}:{port}'],
                                      value_serializer=lambda x: dumps(x).encode('utf-8'))

    def send_data(self, data):
        self.producer.send(self.topic, value=data)
