 
0.1.1 : consumer, rawdata model 추가