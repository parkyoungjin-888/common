from kafka import KafkaConsumer
import json


class KafkaConsumerControl:
    def __init__(self, host: str, port: int, topic: str,
                 auto_offset_reset: str = 'earliest', enable_auto_commit: bool = True, group_id=None):
        self.consumer = KafkaConsumer(
            topic,
            bootstrap_servers=[f'{host}:{port}'],
            auto_offset_reset=auto_offset_reset,
            enable_auto_commit=enable_auto_commit,
            group_id=group_id,
            value_deserializer=lambda x: json.loads(x.decode('utf-8'))
        )

    def get_data(self):
        for message in self.consumer:
            a = message.value
            print(message.value)

    def close(self):
        self.consumer.close()
